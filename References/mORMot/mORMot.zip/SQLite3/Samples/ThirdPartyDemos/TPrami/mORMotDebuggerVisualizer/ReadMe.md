TTimeLog Vizualizer for Delphi IDE debugger
===========================================

By TPrami.

# Presentation

It'll visualize 
* TTimeLog
* TModTime
* TCreateTime

C++ support isn't there (Just code structure to write the Support later).

Helped me to track some bugs in my project.

-Tee-

# Installation

Ensure your *mORMot* source code folders is in your general IDE settings, or add them in package `mORMotDebuggerVisualizer.dpk`, compile and install.

# Forum Thread

See http://synopse.info/forum/viewtopic.php?id=2642

# License

Feel free to use and/or append to Lib and extend if needed.
