Android Java Client for *mORMot*
================================

*by ChinaPeng*


This is some code shared in our forum, at http://synopse.info/forum/viewtopic.php?pid=13115#p13115

Could be used as reference or start point for accessing a *mORMot* server from a Java client - especially an Android client.

Any further input (e.g. writing a simple Java library and a mustache template) is welcome, to allow easy Java client code wrappers generation, just as we do for Cross-Platform Delphi, FPC and SmartMobileStudio.

Thanks ChinaPeng for sharing!