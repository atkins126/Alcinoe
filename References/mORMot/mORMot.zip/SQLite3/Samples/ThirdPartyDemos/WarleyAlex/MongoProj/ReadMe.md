Wine Cellar Application
=======================

powered by Delphi mORMot and MongoDB
------------------------------------

*by warleyalex*

Bye, bye Chile. After a tense match, Brazil breathes giant siggt of relief, defeats Chile on penaults. 
If you don't know Chile is fortunate to have climate conditions that are ideal for good wine grapes.

Guess what? I've created an Wine Cellar application powered by Delphi *mORMot* and *MongoDB*.
http://mormot.net
http://mongodb.org

You can take a look at the introduction video:
http://youtu.be/qiFq7-Kp6X8

http://synopse.info/forum/viewtopic.php?pid=11293#p11293