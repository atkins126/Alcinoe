#!/bin/bash

fossil status > $1