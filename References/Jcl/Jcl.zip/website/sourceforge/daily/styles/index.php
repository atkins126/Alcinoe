<?php

Header("Location: http://jcl.sf.net/daily/");

?>
