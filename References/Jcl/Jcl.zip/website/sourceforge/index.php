<?php header("Location: http://wiki.delphi-jedi.org/index.php?title=JEDI_Code_Library"); exit; ?>
