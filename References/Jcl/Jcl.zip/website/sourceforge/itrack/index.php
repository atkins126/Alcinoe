<?php header("Location: http://issuetracker.delphi-jedi.org/"); exit; ?>
